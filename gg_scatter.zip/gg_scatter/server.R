
library(shiny)


shinyServer(function(input, output) {

    output$scatter <- renderPlot({
      
      mtc <- mtcars[ ,c(input$VarX,input$VarY,input$Color)]
      mtc[,3] <- as.factor(mtc[,3])
      ggplot(data = mtc, aes(x=mtc[,1],y=mtc[,2],color=mtc[,3]))+
        geom_point()+
        labs(x=colnames(mtc)[1], y=colnames(mtc)[2], 
             color=colnames(mtc)[3], 
             title = paste("Scatter Plot of", input$VarX, "Vs", input$VarY))
      

    })

})
