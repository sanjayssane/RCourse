
library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

    # Application title
    titlePanel("Scatter"),

    sidebarLayout(
        sidebarPanel(
          selectInput(inputId = "VarX",
                      label = "Select X-axis Variable:",
                      choices = list("mpg",
                                     "disp", "hp",
                                     "drat", "wt","qsec","carb")),
          selectInput(inputId = "VarY",
                      label = "Select Y-axis Variable:",
                      choices = list("disp","mpg",
                                     "hp","drat", "wt","qsec","carb")) ,
          selectInput(inputId = "Color",
                      label = "Select Colour Variable:",
                      choices = as.list(c("am",
                                          "vs", "gear", 
                                          "cyl")))         
        ),

        mainPanel(
            plotOutput("scatter")
        )
    )
))
