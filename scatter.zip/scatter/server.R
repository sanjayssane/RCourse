#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {

    output$scatter <- renderPlot({
      
      mtc <- mtcars[ ,c(input$VarX,input$VarY)]
      plot(mtc[,1],mtc[,2],
           xlab = colnames(mtc)[1],
           ylab = colnames(mtc)[2],
           main = paste("Scatter Plot of", input$VarX, "Vs", input$VarY),
           col="violet",pch=15
      )

    })

})
