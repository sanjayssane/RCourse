#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

    # Application title
    titlePanel("Scatter"),

    sidebarLayout(
        sidebarPanel(
          selectInput(inputId = "VarX",
                      label = "Select X-axis Variable:",
                      choices = list("mpg",
                                     "disp", "hp",
                                     "drat", "wt","qsec","carb")),
          selectInput(inputId = "VarY",
                      label = "Select Y-axis Variable:",
                      choices = list("disp","mpg",
                                     "hp","drat", "wt","qsec","carb"))          
        ),

        mainPanel(
            plotOutput("scatter")
        )
    )
))
